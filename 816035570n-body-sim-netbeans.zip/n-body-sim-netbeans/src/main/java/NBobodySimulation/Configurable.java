package NBobodySimulation;

public interface Configurable {
    public void configure(SimulationSettings config);
}
