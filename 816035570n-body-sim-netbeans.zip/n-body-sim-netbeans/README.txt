run the Runner class

MUST load a preset or click the add button and add bodies before pressing start

ALWAYS press Start then Stop to cancel a sim in order to load a preset or a customly added. (will break if u try to load without stopping sim or paused before stopping)

if u wish to reload a preset click the combobox and reselect the option.

must add 3 or more bodies

running the simulation with 8 or more bodies with the grid enabled as well as infinite will eat alot of resources and either crash or lag alot